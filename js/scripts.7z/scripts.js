// STEP_1:
var someMonth;
function theMonth();
var currentMonth;
var summerMonth;
var myLibraryFunction;

// STEP_2:
5 //numeric literal expression
"Hi" //string literal expression
true //boolean literal expression
null //null literal expression

// STEP_3:
let x = 5*(3 - 6); //complex expression

// STEP_4:
let sFirstName;
let sLastName;
let sAddress;
let sCity;
let sState;
let nZipCode;
let nYourAge;
let rRefferalSource;
let bMayWeContactYou;

// STEP_5:
let sFirstName;
let sLastName;
sFirstName = "Evgeny";
sLastName = "Popov";

let sAddress = "5555 1st Street, Apt.1";
let sCity = "San Diego";

let nZipCode = 92109, nYourAge = 19;

// STEP_6:
let age = 6;
window.console.log("His child is " + age + " years old.");

// STEP_7:

// STEP_8:
// correct version:
var someString = 'Who once said, \"Only two things are infinite, the universe and human stupidity, and I\'m not sure about the former.\"';
window.console.log(someString);

// STEP_9:
let x = null;
window.console.log(x);
let y;
window.console.log(y);

// STEP_10:
window.console.log(typeof "Hi");//string
window.console.log(typeof 9);//number
window.console.log(typeof true);//boolean
window.console.log(typeof [1, 2, 3]);//object
window.console.log(typeof anything);//undefined

// STEP_11:
let person = "Evgeny Popov";
let nothing = "";
alert("Hello " + person + nothing + ", welcome to the JavaScript class!");

// STEP_12:
let name = "Evgeny";
alert("Hello " + name + nothing + ", welcome to the JavaScript class!");

// STEP_13:
let course = "JavaScript";
alert("Hello " + name + nothing + ", welcome to the " + course + " class!");

// STEP_14:
alert("Hello " + name + nothing + ".\nWelcome to the " + course + " class!");

// STEP_15:
let name = prompt("Enter your name:");
alert("Hello " + name + nothing + ".\nWelcome to the " + course + " class!");

// STEP_16:
let course = prompt("Enter your course:");
alert("Hello " + name + nothing + ".\nWelcome to the " + course + " class!");

// STEP_17:
let x = 10;
let y = 20;
window.console.log(x + y);

// STEP_18:
let x = 20;
window.console.log(x += 20);

// STEP_19:
let x = 20;
window.console.log(x *= 20);

// STEP_20:
let x = 20%3;
window.console.log(x/1);

// STEP_21:
let x = 15;
window.console.log(x > 14);

// STEP_22:
let x = 15;
window.console.log(x === 16);

// STEP_23:
let widget = new Object();
window.console.log(typeof widget);

// STEP_24:
let widget = new Object();
window.console.log(widget instanceof Object);

// STEP_25:
window.console.log(widget instanceof Car);